window.onload = function () {  // Get User Email ID from getUrlParameter and Initiates Authentication Process with Server and Take Action Respectively


    localStorage['user_id'] = getUrlParameter('user_id');
    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email_id:localStorage.user_id,key:"verify"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response==0){
                $("body").html(
                    '<h3>Bad Request</h3>'
                );
                alert("Something went Wrong");
                return ;
            }

            var json=JSON.parse(response);
            if (json.type=="receiver"){
                $("body").html(
                    '<h3>Access Denied</h3>'
                );
                return ;
            }
            else if (json.sign_state=="0"){
                $("body").html('');
                alert("Please Sign in");
                window.location="http://localhost/BloodBank/login/";

            }

            else if (json.sign_state=="1" && json.type=="hospital"){
                initialize();
            }
            else{
                $("body").html('');
                return;
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
            $("body").html(
                '<h3>Bad Request</h3>'
            );
            return ;
        }
    });


};

var getUrlParameter = function getUrlParameter(sParam) {   //Extracts out and Return the GET Request Parameters from the URL

    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};


function initialize() { // Generates a View of "Available Blood Samples" in a User's Hospital 

    $.ajax({
        url: "http://localhost/BloodBank/admin/hospital.php",
        type: 'GET',
        data: {email_id:localStorage.user_id,key:"display_one"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response==0){
                alert("Soemthing went Wrong(Empty)")
                return ;
            }
            var str = "";
            var t = "";
            var id = "";
            var tmp = "";

            var json=JSON.parse(response);
            $.each(json, function (key, value) {

                $.each(value, function (key, val) {

                    if (key == "user_email")  {
                        return ;
                    }
                    if (key != "id") {
                        str += '<td>' + val + '</td>';
                    }
                    else {
                        id = val;
                    }
                });
                var tmp = "<td><button type='button' class='btn btn-danger' onclick='delete_item(\"" + id + "\")'>Delete</button></td>";
                t += '<tr>' + str + tmp+  '</tr>' + '\n';
                str = "";

            });


            $("#table_body").html(t);

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });


}

function delete_item(id) {  //Deletes a Data in a User's Hospital Blood Sample 
    $.ajax({
        url: "http://localhost/BloodBank/admin/hospital.php",
        type: 'GET',
        data: {id:id,key:"remove"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {
            if (response==0){
                alert("Something went Wrong");
                return;
            }
            var obj = JSON.parse(response);
            if (obj.status == "Success") {
                alert("Successfully Removed");
                window.location="http://localhost/BloodBank/Hospital?user_id="+localStorage.user_id;
            }
            else {
                alert("Something went Wrong");
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });




}

function view_data() {  // Redirect the User to View "All Available Blood Samples" in all Hospitals 

    window.location.href = 'http://localhost/BloodBank/Receiver?user_id='+localStorage.user_id;
}


function add() {  // Redirect the User to Add Blood Sample Page
    window.location.href = "http://localhost/BloodBank/Hospital/add.html?user_id="+localStorage.user_id;

}

function add_item() {  //Handles Request from Add.html Page and Adds a New Blood Sample to Hospital's Database  



    var name = $("#name").val();
    var bb = $("#blood_bank").val();
    var bg = $("#bg").val();
    var units = $("#units").val();

    if (name=="" || bb=="" || bg=="" || units==""){
        alert("Please Fill All the Fields Properly");
        return;
    }
    $.ajax({
        url: "http://localhost/BloodBank/admin/hospital.php",
        type: 'GET',
        data: {name: name, key: "add",blood_group:bg,bank:bb,units:units,email_id:localStorage.user_id},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {
            if (response==0){
                alert("Something went Wrong");
                return;
            }    
            var obj = JSON.parse(response);
            if (obj.status == "Success") {
                alert("Successfully Added");
                window.location="http://localhost/BloodBank/Hospital?user_id="+localStorage.user_id;
            }
            else {
                alert("Something went Wrong");
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });

 }


function request_view(){ //Redirects User to Request Page to View All "Blood Sample Requests" to the Hospital

    window.location.href = 'http://localhost/BloodBank/Hospital/Request?user_id='+localStorage.user_id;

}


function sign_out(){ //Signs Out the User//

    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email: localStorage.user_id, key: "auth",act:"out"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {


            if (response==0)
            {
                alert("Something went Wrong");
                return;
            }
            var json = JSON.parse(response);
            if (json.status=="Success"){

                alert("You are logged out");
                window.location="http://localhost/BloodBank/login/";


            }
            else if (json.status == "Failed"){
                alert("Failed");
                window.location="http://localhost/BloodBank/login/";
            }
            else{
                alert("Something went wrong");
                return ;
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });


}

