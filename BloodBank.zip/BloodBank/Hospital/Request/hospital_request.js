window.onload = function () {  // Get User Email ID from getUrlParameter and Initiates Authentication Process with Server and Take Actions Respectively

    localStorage['user_id'] = getUrlParameter('user_id');

    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email_id:localStorage.user_id,key:"verify"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response==0){
                
                $("body").html(
                    '<h3>Bad Request</h3>'
                );
                alert("Something went Wrong");
                return ;
            }

            var json=JSON.parse(response);
            if (json.type=="receiver"){
                $("body").html(
                    '<h3>Access Denied</h3>'
                );
                return;
            }
            else if (json.sign_state=="0"){
                $("body").html('');
                alert("Please Sign in");
                window.location="http://localhost/BloodBank/login/";
            }

            else if (json.sign_state=="1" && json.type=="hospital"){
                initialize();
            }
            else{
                $("body").html('');
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
            $("body").html(
                '<h3>Bad Request</h3>'
            );
           return;
        }

    });



};

var getUrlParameter = function getUrlParameter(sParam) { //Extracts out and Return the GET Request Parameters from the URL
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};


function initialize() { //Generates the View to Display All "Blood Samples Request" of an Hospital

    $.ajax({
        url: "http://localhost/BloodBank/admin/request.php",
        type: 'GET',
        data: {email_id: localStorage.user_id, key: "display"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response==0)
            {
                
                return;
            }

            var str = "";
            var t = "";
            var id = "";
            var tmp = "";

            var json = JSON.parse(response);
            $.each(json, function (key, value) {

                $.each(value, function (key, val) {


                        str += '<td>' + val + '</td>';

                });

                t += '<tr>' + str + '</tr>' + '\n';
                str = "";

            });


            $("#table_body").html(t);

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });




}



function sign_out(){ //Signs out the User

    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email: localStorage.user_id, key: "auth",act:"out"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {


            if (response==0)
            {
                alert("Something went Wrong(Empty)");
                return;
            }
            var json = JSON.parse(response);
            if (json.status=="Success"){

                alert("You are logged out");
                window.location="http://localhost/BloodBank/login/";


            }
            else if (json.status == "Failed"){
                alert("Failed");
                window.location="http://localhost/BloodBank/login/";
            }
            else{
                alert("Something went wrong");
                return ;
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });


}

