window.onload = function () {  // Get User Email ID from getUrlParameter and Initiates Authentication Process with Server and Take Actions Respectively

    localStorage['user_id'] = getUrlParameter('user_id');
    $("#action").hide();
    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email_id: localStorage.user_id, key: "verify"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {
            var json = JSON.parse(response);

            if (response == 0) {
                initialize_public_page();
                return;
            }

            if (json.sign_state == "0") {
                $("body").html('');
                alert("Please Sign in");
                window.location = "http://localhost/BloodBank/login/";
            }
            else if (json.type=="hospital") {

                initialize_public_page();
                return;
            }
            else if (json.sign_state == "1" && json.type == "receiver") {
                initialize_req_page();
            }
            else {
                $("body").html('');
            }

        },
        error: function () {
          
            $("body").html(
                '<h3>Bad Request</h3>'
            );
            alert("Unable to Connect to the Server");
            return;
        }
    });



};


var getUrlParameter = function getUrlParameter(sParam) { //Extracts out and Return the GET Request Parameters from the URL
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};


function initialize_public_page() {  //Initializes the Page for Public Other than the Receiver

    $("#action").hide();
    $.ajax({
        url: "http://localhost/BloodBank/admin/hospital.php",
        type: 'GET',
        data: {key: "display_all"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response == 0) {

                alert("Something went Wrong(Empty)");
                return;
            }
            var str = "";
            var t = "";
            var id = "";
            var tmp = "";

            var json = JSON.parse(response);
            $.each(json, function (key, value) {

                $.each(value, function (key, val) {

                    if (key == "user_email" || key == "id") {

                        return;

                    }

                    else {
                        str += '<td>' + val + '</td>';
                    }
                });

                t += '<tr>' + str + '</tr>' + '\n';
                str = "";

            });


            $("#table_body").html(t);

        },
        error: function () {
            alert("Something went wrong");
        }
    });


}

function initialize_req_page() { //Initializes the Page for Signed in Receivers 


    $("#action").show();
    $.ajax({
        url: "http://localhost/BloodBank/admin/hospital.php",
        type: 'GET',
        data: {key: "display_all"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {

            if (response == 0) {

                alert("Something went Wrong(Empty)");
                return;
            }
            var str = "";
            var t = "";
            var id = "";
            var tmp = "";

            var json = JSON.parse(response);
            $.each(json, function (key, value) {

                $.each(value, function (key, val) {

                    if (key == "user_email") {
                        return;
                    }
                    if (key != "id") {
                        str += '<td>' + val + '</td>';
                    }
                    else {
                        id = val;
                    }


                });
                var tmp = "<td><button type='button' class='btn btn-danger' onclick='send_req(\"" + id + "\")'>Request Blood</button></td>";
                t += '<tr>' + str + tmp + '</tr>' + '\n';
                str = "";

            });


            $("#table_body").html(t);

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });


}

function send_req(id) {  //Send Blood Sample Request to Respective Hospital

    $("#action").show();
    $.ajax({
        url: "http://localhost/BloodBank/admin/request.php",
        type: 'GET',
        data: {key: "req", id: id, req_id: localStorage.user_id},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {
            if (response == 0) {

                alert("Something went Wrong(Empty)");
                return;
            }

            var json = JSON.parse(response);
            if (json.status == "Success") {
                alert("Request Sent");
            }
            else if (json.status == "Unauthorized") {
                alert("(Access Denied) Sorry,You cannot send Blood Sample Request");
            }
            else {
                alert("Something went wrong")
            }
        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });
}



function sign_out(){  //Signs out the Valid User 

    $.ajax({
        url: "http://localhost/BloodBank/admin/users.php",
        type: 'GET',
        data: {email: localStorage.user_id, key: "auth",act:"out"},
        contentType: 'application/json; charset=UTF-8',
        success: function (response) {


            if (response==0)
            {
                alert("Something went Wrong(Empty)");
                return;
            }
            var json = JSON.parse(response);
            if (json.status=="Success"){

                alert("You are logged out");
                window.location="http://localhost/BloodBank/login/";


            }
            else if (json.status == "Failed"){
                alert("Failed");
                window.location="http://localhost/BloodBank/login/";
            }
            else{
                alert("Something went wrong");
                return ;
            }

        },
        error: function () {
            alert("Unable to Connect to the Server");
        }
    });


}



