<?php

require_once("include_classes.php");

class request
{

    private $db;

    function __construct()
    {
        $this->db = new Dbase();
    }

    function display($e_id)  //Return all "Blood Requests" to an Hospital
    {
        $data = $this->db->fetchAll("select * from blood_req where user_email='$e_id'");
        $loc = array();
        $email = array();
        $loc = array();
        $contact = array();
        $name=array();
        foreach ($data as $key => $value) {
            $email[] = $value['req_id'];
        }

        for ($i = 0; $i < sizeof($email); $i++) {
            $loc[] = $this->db->fetchOne("select address from receiver where user_email='$email[$i]'");
            $contact[] = $this->db->fetchOne("select contact from receiver where user_email='$email[$i]'");
            $name[] = $this->db->fetchOne("select name from receiver where user_email='$email[$i]'");
        }
        for ($i = 0; $i < sizeof($email); $i++) {
            $data[$i]['location'] = $loc[$i]['address'];
            $data[$i]['contact'] = $contact[$i]['contact'];
            $data[$i]['user_email'] = $name[$i]['name'];

        }
        if (empty($data)) return "0";
        return $data;
    }


    function request($id,$email) // Generates a Request of "Blood Samples" to an Hospital
    {

        $data = $this->db->fetchOne("select * from hospital where id='$id'");
        if (empty($data)) return "0";
        $req_user = $this->db->fetchOne("select blood_group from receiver where user_email='$email'");
        if (empty($req_user)) return "0";
        if ($req_user['blood_group']!= $data['blood_group']) return "Unauthorized";
        $fields = array("user_email"=>$data['user_email'],"req_id"=>$email,"blood_group"=>$data['blood_group'],"units"=>$data['units']);
        $this->db->prepareInsert($fields);
        $this->db->insert('blood_req');
        if (($this->db->_affected_rows) == 0) return "Failed";
        return "Success";



    }

}

?>