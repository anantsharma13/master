<?php

require_once("include_classes.php");

$obj = new hospital();

if (!strcmp($_GET['key'], "display_all")) {
    $resp = $obj->display_all();

    if ($resp=="0") reply(0);
    $E_data = json_encode($resp);
    reply($E_data);
}

else if (!strcmp($_GET['key'], "display_one")) {
    if (empty($_GET['email_id'])) reply(0);
    $resp = $obj->display_one($_GET['email_id']);
    if ($resp=="0") reply(0);
    $E_data = json_encode($resp);
    reply($E_data);
}
else if (!strcmp($_GET['key'], "add")) {
    if (empty($_GET['name']) || empty($_GET['email_id'])|| empty($_GET['blood_group']) || empty($_GET['units'])|| empty($_GET['bank']) ) reply(0);
    $resp = $obj->add($_GET['email_id'] ,$_GET['blood_group'],$_GET['units'],$_GET['bank'],$_GET['name']);
    if ($resp=="0") reply(0);
    $resp=array("status"=>$resp);
    $E_data = json_encode($resp);
    reply($E_data);
}
else if (!strcmp($_GET['key'], "remove")) {
    if (empty($_GET['id']) ) reply(0);
    $resp = $obj->remove($_GET['id']);
    if ($resp=="0") reply(0);
    $resp=array("status"=>$resp);
    $E_data = json_encode($resp);
    reply($E_data);
}

else {
    reply(0);
}


function reply($resp)
{
    echo $resp;
    die();
}

?>