<?php

require_once("include_classes.php");

$obj = new users();

if (!strcmp($_GET['key'], "auth")) {

    if (empty($_GET['act'])) reply(0);
    if ($_GET['act']=="in") {
        if (empty($_GET['email']) && empty($_GET['pwd']) && empty($_GET['act'])) reply(0);
        $resp = $obj->auth($_GET['email'], $_GET['pwd']);
        if ($resp=="invalid") reply(0);
        $E_data = json_encode($resp);
        reply($E_data);
    }
    else if ($_GET['act']=="out") {
        if (empty($_GET['email'])  && empty($_GET['act']) ) reply(0);
        $resp = $obj->sign_out($_GET['email']);
        if ($resp=="invalid") reply(0);
        $E_data = json_encode($resp);
        reply($E_data);

    }
}


else if (!strcmp($_GET['key'], "verify")) {
    if (empty($_GET['email_id'])) reply(0);
    $resp = $obj->verify($_GET['email_id']);
    if ($resp=="0") reply(0);
    $E_data = json_encode($resp);
    reply($E_data);
}



else if (!strcmp($_GET['key'], "reg_hospital")) {
    if (empty($_GET['name'])||empty($_GET['email_id'])||empty($_GET['address'])||empty($_GET['contact'])||empty($_GET['pwd']) ) reply(0);
    $resp = $obj->insert_hospital($_GET['name'],$_GET['pwd'],$_GET['address'],$_GET['contact'],$_GET['email_id']);
    if ($resp=="Failed") reply(0);
    $resp=array("status"=>$resp);
    $E_data = json_encode($resp);
    reply($E_data);
}

else if (!strcmp($_GET['key'], "reg_receiver")) {
    if (empty($_GET['name'])||empty($_GET['email_id'])||empty($_GET['address'])||empty($_GET['contact'])||empty($_GET['gen'])||empty($_GET['pwd'])||empty($_GET['blood_grp'])||empty($_GET['age']) ) reply(0);
    $resp = $obj->insert_receiver($_GET['name'],$_GET['pwd'],$_GET['address'],$_GET['contact'],$_GET['gen'],$_GET['blood_grp'],$_GET['age'],$_GET['email_id']);
    if ($resp=="Failed") reply(0);
    $resp=array("status"=>$resp);
    $E_data = json_encode($resp);
    reply($E_data);
}



else {
    reply(0);
}


function reply($resp)
{
    echo $resp;
    die();
}

?>