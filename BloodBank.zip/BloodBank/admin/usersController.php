<?php

require_once("include_classes.php");

class users
{

    private $db;

    function __construct()
    {
        $this->db = new Dbase();
    }

    function verify($e_id)  //Returns Logged In/Out Status and Type of User
    {

        $type = $this->db->fetchOne("select type,sign_state from users where user_email='$e_id'");
        if (empty($type)) return "0";
        $rep=array("sign_state"=>$type['sign_state'],"type"=>$type['type']);
        return $rep;
    }

    function auth($email, $pwd) // Updates Logged In or Out Status of the User
    {

        $state = $this->db->fetchOne("select sign_state,type from users where user_email='$email' AND password='$pwd'");

        if ($state['sign_state'] == "") return "invalid";
        $field = array("sign_state" => "1");
        $where = array("user_email" => $email);
        $this->db->prepareUpdate($field, $where);
        $this->db->update('users');
        if (($this->db->_affected_rows) == 0) $rep["status"] = "Failed";
        $rep["status"] = "Success";
        $rep["type"] = $state["type"];
        return $rep;
    }

    function sign_out($email) //Signs Out the Respective User
    {

        $state = $this->db->fetchOne("select sign_state,type from users where user_email='$email'");

        if ($state['sign_state'] == "") return "invalid";
        $field = array("sign_state" => "0");
        $where = array("user_email" => $email);
        $this->db->prepareUpdate($field, $where);
        $this->db->update('users');
        if (($this->db->_affected_rows) == 0) $rep["status"] = "Failed";
        $rep["status"] = "Success";
        $rep["type"] = $state["type"];
        return $rep;
    }

    function insert_hospital($name, $pwd, $add, $contact, $e_id) // Inserts the Hospital's Data
    {
        $state = $this->db->fetchOne("select email_id from reg_hospital where email_id='$e_id'");

        if ($state['email_id'] != "") return "Failed";

        $fields = array("email_id" => $e_id, "name" => $name, "address" => $add, "contact" => $contact);
        $this->db->prepareInsert($fields);
        $this->db->insert('reg_hospital');
        $fields = array("user_email" => $e_id, "password" => $pwd, "sign_state" => "0", "type" => "hospital");
        $this->db->prepareInsert($fields);
        $this->db->insert('users');
        if (($this->db->_affected_rows) == 0) return "Failed";
        return "Success";
    }


    function insert_receiver($name, $pwd, $add, $contact, $gen, $bg, $age, $e_id) // Inserts a Receiver's Data
    {

        $state = $this->db->fetchOne("select user_email from receiver where user_email='$e_id'");

        if ($state['user_email'] != "") return "Failed";

        $fields = array("user_email" => $e_id, "name" => $name, "blood_group" => $bg, "gender" => $gen, "age" => $age, "address" => $add, "contact" => $contact);
        $this->db->prepareInsert($fields);
        $this->db->insert('receiver');
        $fields = array("user_email" => $e_id, "password" => $pwd, "sign_state" => "0", "type" => "receiver");
        $this->db->prepareInsert($fields);
        $this->db->insert('users');
        if (($this->db->_affected_rows) == 0) return "Failed";
        return "Success";
    }


}