<?php


require_once("include_classes.php");

class hospital
{

    private $db;

    function __construct()
    {
        $this->db = new Dbase();
    }

    function display_all(){   //Returns Information of All Hospitals Data

        $data = $this->db->fetchAll("select * from hospital");

        $loc=array();
        $email=array();
        $loc=array();
        $contact=array();
        foreach ($data as $key => $value){
            $email[]=$value['user_email'];
        }

        for ($i=0;$i<sizeof($email);$i++){
            $loc[] = $this->db->fetchOne("select address from reg_hospital where email_id='$email[$i]'");
            $contact[] = $this->db->fetchOne("select contact from reg_hospital where email_id='$email[$i]'");
        }
        for ($i=0;$i<sizeof($email);$i++){
            $data[$i]['location']=$loc[$i]['address'];
            $data[$i]['contact']=$contact[$i]['contact'];
        }
        if(empty($data)) return "0";
        return $data;
    }

    function display_one($e_id){ //Returns Information of One Hospital
        $data = $this->db->fetchAll("select * from hospital where user_email='$e_id'");
        $loc = $this->db->fetchOne("select address from reg_hospital where email_id='$e_id'");
        $contact = $this->db->fetchOne("select contact from reg_hospital where email_id='$e_id'");
        for ($i=0;$i<sizeof($data);$i++){
            $data[$i]['location']=$loc['address'];
            $data[$i]['contact']=$contact['contact'];
        }
        if(empty($data)) return "0";
        return $data;
    }

    function add($e_id,$bg,$units,$bb,$name){ //Add's the "Blood Sample Data" of an Hospital  

        $fields = array("user_email"=>$e_id,"name" => $name,"blood_bank" => $bb,"blood_group"=>$bg,"units" => $units);
        $this->db->prepareInsert($fields);
        $this->db->insert('hospital');
        if (($this->db->_affected_rows) == 0) return "Failed";
        return "Success";
    }

    function remove($id){ //Removes "Blood Sample Data" of an Hospital
        $this->db->query("Delete from hospital where id='$id'");
        if (($this->db->_affected_rows) == 0) return "Failed";
        return "Success";
    }

}

?>