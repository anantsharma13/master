<?php

require_once("include_classes.php");

$obj = new request();


if (!strcmp($_GET['key'], "display")) {
    if (empty($_GET['email_id'])) reply(0);
    $resp = $obj->display($_GET['email_id']);
    if ($resp=="0") reply(0);
    $E_data = json_encode($resp);
    reply($E_data);
}
else if (!strcmp($_GET['key'], "req")) {
    if (empty($_GET['id']) || empty($_GET['req_id'])) reply(0);
    $resp = $obj->request( $_GET['id'] ,$_GET['req_id']);
    if ($resp=="0") reply(0);
    $resp=array("status"=>$resp);
    $E_data = json_encode($resp);
    reply($E_data);
}
else {
    reply(0);
}


function reply($resp)
{
    echo $resp;
    die();
}

?>