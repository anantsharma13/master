<?php

//Include All Classes Here and Include this Class Only to Other Files 
require_once("Dbase.php");
require_once("usersController.php");
require_once("hospitalController.php");
require_once("requestController.php");

?>
