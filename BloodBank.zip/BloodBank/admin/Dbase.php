<?php

class Dbase
{

    private $_host = "localhost";
    private $_user = "root";
    private $_pass = "";
    private $_name = "blood_bank";

    private $_conndb = false;
    public $_last_query = null;
    public $_affected_rows = 0;

    public $_insert_keys = array();
    public $_insert_values = array();
    public $_update_sets = array();
    public $_update_wheres = array();




    public function __construct()
    {
        $this->connect();

    }

    private function connect()
    {
        $this->_conndb = mysqli_connect($this->_host, $this->_user, $this->_pass, $this->_name);
        mysqli_set_charset($this->_conndb, "utf8");

    }

    public function close()
    {
        if (!mysqli_close($this->_conndb)) {
            die("Closing connection failed");
        }
    }

    public function escape($value)
    {
        if (function_exists("mysql_real_escape_string")) {
            if (get_magic_quotes_gpc()) {
                $value = stripslashes($value);
            }

            $value = mysql_real_escape_string($value);
        } else {
            if (!get_magic_quotes_gpc()) {
                $value = addcslashes($value,'m');
            }
        }

        return $value;
    }


    public function query($sql)
    {
        $this->_last_query = $sql;
        $result = mysqli_query($this->_conndb, $sql);
        $this->displayQuery($result);
        return $result;
    }


    public function displayQuery($result)
    {
        if (!$result) {
            
        } else {
            $this->_affected_rows = mysqli_affected_rows($this->_conndb);

        }
    }


    public function fetchAll($sql)
    {
        $result = $this->query($sql);
        $out = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $out[] = $row;
        }
        mysqli_free_result($result);
        return $out;
    }

    public function fetchOne($sql)
    {
        $out = $this->fetchAll($sql);
        return array_shift($out);
    }

    public function lastId()
    {
        return mysqli_insert_id($this->_conndb);
    }

    public function prepareInsert($array = null)
    {
        if (!empty($array)) {
            $this->_insert_keys = array();
            $this->_insert_values = array();

            foreach ($array as $key => $value) {
                $this->_insert_keys[] = $key;
                $this->_insert_values[] = $this->escape($value);
            }
        }
    }

    public function insert($table = null)
    {
        if (!empty($table) && !empty($this->_insert_keys) && !empty($this->_insert_values)) {
            $sql = "insert into`{$table}` (`";
            $sql .= implode("`, `", $this->_insert_keys);
            $sql .= "`) values ('";
            $sql .= implode("', '", $this->_insert_values);
            $sql .= "')";



            if ($this->query($sql)) {
                $this->_id = $this->lastId();
                return true;
            }

        }
        return false;

    }

    public function prepareUpdate($set = null, $where = null)
    {
        if (!empty($set) && !empty($where)) {
            //$array = $this->cleanForUpdate($array);
            $this->_update_sets = array();
            $this->_update_wheres = array();

            foreach ($set as $key => $value) {
                $this->_update_sets[] = "`{$key}` = '" . $this->escape($value) . "'";
            }

            foreach ($where as $key => $value) {
                $this->_update_wheres[] = "`{$key}` = '" . $this->escape($value) . "'";
            }
        }
    }

    private function cleanForUpdate($array)
    {
        foreach ($this->exclude_from_update as $index) {
            unset($array[$index]);
        }
        return $array;
    }


    public function update($table = null)
    {
        if (!empty($table) && !empty($this->_update_sets) && !empty($this->_update_wheres)) {
            $sql = "update `{$table}`set ";
            $sql .= implode(", ", $this->_update_sets);
            $sql .= " where ";//`{$ref}` = '" . $this->escape($ref_value) . "'";
            $sql .= implode(" AND ", $this->_update_wheres);

            return $this->query($sql);
        }

        return false;
    }


}

?>