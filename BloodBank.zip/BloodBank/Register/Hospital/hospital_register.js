window.onload = function () {  // Function is Called After Document is Loaded
    initialize();
    validator();
    submit();
    screen_adjust_handler();
    keyPressListener();

};
var error_status = {};
var fields = ["hospital_name", "user_email", "user_pwd", "user_add", "user_contact"];

function submit() {   /* After all Validations Other than "Empty Field Validation", this Function Validates for Empty Fields and Register the
                      User To Server in case of Successful Validation and Redirect to Login */                          

    var i = 0;
    var empty_flag = false;
    var error_flag = false;
    $("#reg_btn").click(function () {
        empty_flag = false;
        error_flag = false;
        for (i = 0; i < fields.length; i++) {
            $("#" + fields[i] + "_msg").html('');
        }
        for (i = 0; i < fields.length; i++) {
            if (!$("#" + fields[i]).val()) {
                error_status[fields[i]] = "Please fill the Above Field";
                $("#" + fields[i] + "_msg").html(error_status[fields[i]]);
                empty_flag = true;
                break;
            }
        }
        if (empty_flag == true) {

            return "";

        }

        for (var k in error_status) {
            if (error_status.hasOwnProperty(k)) {
                if (error_status[k] != "") {
                    $("#" + k + "_msg").html(error_status[k]);
                    error_flag = true;
                }

            }
        }


        if (error_flag == true) {

            return "";
        }


        var user_type;
        var user_gen;
        var pwd = $("#user_pwd").val();
        var h_name = $("#hospital_name").val();
        var e_id = $("#user_email").val();
        var add = $("#user_add").val();
        var contact = $("#user_contact").val();

        $.ajax({
            url: "http://localhost/BloodBank/admin/users.php",
            type: 'GET',
            data: {email_id: e_id, name: h_name, key: "reg_hospital", address: add, pwd: pwd, contact: contact},
            contentType: 'application/json; charset=UTF-8',
            success: function (response) {
                if (response==0){
                    alert("Something went wrong");
                    return;
                }
                var obj = JSON.parse(response);

                if (obj.status == "Success") {
                    reg_suc();
                }
                else if (obj.status == "Failed"){
                    alert("You are already Registered");
                }
                else {
                    alert("Something went Wrong");
                }

            },
            error: function () {
                alert("Unable to Connect to the Server");
            }
        });
    });
}

function initialize() {  // Initializes Status Messages and Input Fields with Null or Empty String
    $('#suc_msg').hide();
    $("#hospital_name_msg").html('');
    $("#user_msg").html('');
    $("#user_pwd").html('');
    $("#user_pwd_msg").html('');
    $("#user_email_msg").html('');
    $("#user_add_msg").html('');
    $("#user_contact_msg").html('');
    $("#hospital_name").val('');
    $("#user_email").val('');
    $("#user_add").val('');
    $("#user_contact").val('');

}

function keyPressListener() { // Listen to Keypress events on Input Fields and Set Status to Empty String

    $("#hospital_name").keypress(function () {
        error_status.hospital_name = "";
        $("#hospital_name_msg").html(error_status["hospital_name"]);

    });
    $("#user_email").keypress(function () {
        error_status.user_email = "";
        $("#user_email_msg").html(error_status["user_email"]);

    });
    $("#user_add").keypress(function () {
        error_status.user_add = "";
        $("#user_add_msg").html(error_status["user_add"]);

    });
    $("#user_contact").keypress(function () {
        error_status.user_contact = "";
        $("#user_contact_msg").html(error_status["user_contact"]);
    });
    $("#user_pwd").keypress(function () {
        error_status.user_pwd = "";
        $("#user_pwd_msg").html(error_status["user_contact"]);
    });

}

function validator() { //Validates Input Fields 
    $("#hospital_name").focusout(function () {
        hospital_name_validator();
    });
    $("#user_email").focusout(function () {
        email_validator();
    });
    $("#user_add").focusout(function () {

        add_validator();
    });
    $("#user_contact").focusout(function () {
        contact_validator();
    });
}


function hospital_name_validator() { // Hospital Name Input Field Validator
    var hospital_name = $("#hospital_name").val();
    if (hospital_name.length > 0) {

        if (alpha_val(hospital_name)) {
            error_status.hospital_name = "";
            $("#hospital_name_msg").html(error_status["hospital_name"]);
        }
        else {
            error_status.hospital_name = 'Please Enter the Valid First name';
            $("#hospital_name_msg").html(error_status["hospital_name"]);

        }
    }
    else {
        error_status.hospital_name = "";
        $("#hospital_name_msg").html(error_status["hospital_name"]);

    }
}

function add_validator() {  // Address Input Field Validator
    var user_add = $("#user_add").val();
    if (user_add.length < 20 && user_add.length > 0) {
        error_status.user_add = "Please Enter at least 20 characters";
        $("#user_add_msg").html(error_status["user_add"]);

    }
    else {
        error_status.user_add = "";
        $("#user_add_msg").html(error_status["user_add"]);

    }

}

function contact_validator(data) {   // Contact Input Field Validator
    var user_contact = $("#user_contact").val();
    if (user_contact.length >= 7 && user_contact.length > 0) {
        error_status.user_contact = "";
        if (num_val(user_contact)) {
            error_status.user_contact = "";
        }
        else {
            error_status.user_contact = "Please Enter the Valid Contact number";

        }
        $("#user_contact_msg").html(error_status["user_contact"]);

    }
    else if (user_contact.length < 7 && user_contact.length > 0) {
        if (num_val(user_contact)) {
            error_status.user_contact = "Please Enter at least 7 digits";
            $("#user_contact_msg").html(error_status["user_contact"]);
        }
        else {
            error_status.user_contact = "Please Enter the Valid Contact number";
            $("#user_contact_msg").html(error_status["user_contact"]);
        }
    }
    else {
        error_status.user_contact = "";
        $("#user_contact_msg").html(error_status["user_contact"]);

    }

}


function reg_suc() {  //Prints Success Message on Screen After Successful Registeration
    $('.container').hide();
    $('.footer').hide();
    $('#suc_msg').show().center();

}

jQuery.fn.center = function () {   // Center Align the Success Message On Screen
    this.css("position", "absolute");
    this.css("top", Math.max(0, (($(window).height() - $(this).outerHeight()) / 2) +
    $(window).scrollTop()) + "px");
    this.css("left", Math.max(0, (($(window).width() - $(this).outerWidth()) / 2) +
    $(window).scrollLeft()) + "px");
    return this;
};

function alpha_val(data) {  //Checks if data has only Alphabets or not
    var alpha = false;
    var pos;
    var i = 0;
    for (i = 0; i < data.length; i++) {
        pos = data.charCodeAt(i);

        if ((pos >= 65 && pos <= 90) || (pos >= 97 && pos <= 122) || pos == 32) {
            alpha = true;
        }
        else {
            alpha = false;
            break;
        }
    }
    return alpha;
}

function num_val(data) {  //Checks if data has digits only or not
    var alpha = false;
    var pos;
    var i = 0;
    for (i = 0; i < data.length; i++) {
        pos = data.charCodeAt(i);
        if ((pos >= 48 && pos <= 57) || pos == 32) {
            alpha = true;
        }
        else {
            alpha = false;
            break;
        }
    }
    return alpha;

}


function screen_adjust_handler() {  //On Window Resize,Center Align the Success Message 

    $(window).resize(function () {
        $('#suc_msg').center();
    });

}
