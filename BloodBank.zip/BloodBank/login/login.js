window.onload = function () {   // function is Called After Document is Loaded 
    
    initialize();
    btn_trigger();
    key_press_trig();


};
function initialize(){  // Initializes the  Fields with Empty Value
    $('#email').val('');
    $('#pwd').val('');
    $("#status").html("");

}

function btn_trigger() {  // Listen to Submit Button Click Event

    $("#btn").click(function (e) {
        validator();
    });

}
function key_press_trig() {  // Keypress Event Listener to Remove Error Status Message

    $("#email").keypress(function () {

        $("#status").html("");
    });
    $("#pwd").keypress(function () {

        $("#status").html("");
    });
}
function validator() {  // Validates the User Input and Request the Server to Authenticate the User and Take Respective Actoin
    
    var email=$('#email').val();
    var pwd=$('#pwd').val();
    if( !email || !pwd ) {

        $("#status").html('Please fill the above fields');
    }
    else {


        $.ajax({
            url: "http://localhost/BloodBank/admin/users.php",
            type: 'GET',
            data: { email:email,pwd:pwd ,key:"auth",act:"in"},
            contentType: 'application/json; charset=UTF-8',
            success: function (response) {
                
                if(response==0){

                    alert("Something went Wrong");
                    return;
                }                

                var obj=JSON.parse(response);
                if (obj.status=="Success" || obj.status=="Failed"){
                    if (obj.status=="Failed"){
                        alert("You were already logged in");
                    }
                    if (obj.type=="receiver"){

                        window.location="http://localhost/BloodBank/Receiver?user_id="+email;


                    }
                    else if (obj.type=="hospital"){

                        window.location ="http://localhost/BloodBank/Hospital?user_id="+email;

                    }

                }

                else if( obj.status=="invalid"){

                    alert("You are not Registered");
                }



            },
            error: function () {

                alert("Unable to Connect to the Server")
            }
        });
    
    }

}
